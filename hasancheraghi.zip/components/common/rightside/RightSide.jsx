import AboutHeader from "../../about/AboutHeader";
import WhatIDo from "../../about/ido/WhatIDo";

const RightSide = () => {
    return (
        <section className="flex flex-col">

        </section>
    );
}

export default RightSide;