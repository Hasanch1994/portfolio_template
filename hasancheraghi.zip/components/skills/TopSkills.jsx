const TopSkills = () => {
    return (
        <div className="bg-gray-g50 w-full h-48 flex-col flex justify-center items-center">

            <h4 className="text-black text-2xl font-bold">Skills</h4>

            <h4 className="text-gray-g500 text-xl mt-4">In here there are skills that I've worked in and also learn it</h4>

        </div>
    );
}

export default TopSkills;