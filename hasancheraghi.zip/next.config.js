module.exports = {
  reactStrictMode: true,
  distDir: 'build',
}
